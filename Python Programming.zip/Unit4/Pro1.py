try:
    f=open("MyFile",'w')
    a=int(input("Enter a divider:"))
    b=int(input("Enter a divisior:"))
    c=a/b
    f.write("writing C")
except ZeroDivisionError:
    print("Zero Division Error")
else:
    print("c=",c)
finally:
    f.close()
    print("file closed")