import os
print("It return current working directory")
print(os.getcwd()) #It return current working directory
print("return list of the function of os")
print(dir(os)) #return list of the function of os
