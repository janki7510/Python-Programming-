try:
    f=open("MyFile","w")
    sum= 10+"Hello" #TypeError
    eval("x=10")#SyntaxError
    x=(b) #NameError
    f.write("File Created")
except TypeError:
    print("Type error")
except SyntaxError:
    print("Syntax Error")
except NameError:
    print("Name Error")
finally:
    f.close()
    print("file closed")
