import glob
print("List from directory wildcard searches:",glob.glob('*.py')) #It return all .py file from current working directory