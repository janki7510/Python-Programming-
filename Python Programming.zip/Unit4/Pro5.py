from datetime import date
now=date.today()
bd=date(2003,10,31)
age=now-bd
print(age.days)
years=int(age.days/365)
print(f"You are {years} old")