from Pro9 import *
s1 = Student()
id=int(input("Enter id:"))
s1.setId(id)
name=input("Enter Name:")
s1.setName(name)
marks=int(input("Enter marks:"))
s1.setMark(marks)

print("ID:",s1.getId())
print("Name:",s1.getName())
print("Marks:",s1.getMark())