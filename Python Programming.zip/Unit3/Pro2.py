class Student:
    def __init__(self,name,age,marks):
        self.name=name
        self.age=age
        self.marks=marks
    def display(self):
        print("Name:",self.name)
        print("Age:",self.age)
        print("Marks:",self.marks)

name=input("Enter Student name:")
age=int(input("Enter Student age:"))
marks=float(input("Enter Student marks:"))
s1=Student(name,age,marks)
s1.display()
#s2=Student(name,age,marks)
#s2.display()


