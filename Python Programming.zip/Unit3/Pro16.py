class MyClass1:
    def __init__(self,a):
        self.a=a
    def __add__(self,other):
        return self.a+other.a
class MyClass2:
    def __init__(self,a):
        self.a=a

o1=MyClass1(7)
o2=MyClass2(10)
o3=o1+o2
print("Sum of two object is:",o3)