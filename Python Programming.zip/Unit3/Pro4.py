class Student:
    def setName(self,name):
        self.name=name
    def getName(self):
        return self.name
    def setMark(self,mark):
        self.mark=mark
    def getMark(self):
        return self.mark

n=int(input("Entr How many students:"))
i=0
while(i<n):
    s=Student()
    name=input("Enter Name:")
    s.setName(name)
    mark=int(input("Enter Mark:"))
    s.setMark(mark)
    print("Name:", s.getName())
    print("Mark:",s.getMark())
    i+=1
    print("____________________")