class Student:
    def __init__(self):
        self.x=10
    def modify(self):
        self.x += 10

s1=Student()
s2=Student()
print("value of x in object s1 is:",s1.x)
print("value of x in object s2 is:",s2.x)

s1.modify()
print("value of x in s1 after modification:",s1.x)
print("value of x in s2 after modification in s1:",s2.x)

class Student1:
    y=10 #class object variable or static variable
    @classmethod
    def modify(cls):
        cls.y += 10
o1=Student1()
o2=Student1()
print("value of y in object o1 is:",o1.y)
print("value of y in object o2 is:",o2.y)

o1.modify()
print("value of y in o1 after modification in o1:",o1.y)
print("value of y in o2 after modification in o1:",o2.y)
o2.modify()
print("value of y in o1 after modification in o2:",o1.y)


