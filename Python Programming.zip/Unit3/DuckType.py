"""Polymorphism
-Duck Typing
-Operator Overloading
-Method Overloading
"""

#Duck Typing (anything is behaving like a duck is a duck)
class A:
    def fun(self):
        print("Hi this is fun 1")

class B:
    def abc(self):
        print("Hi this is abc")
    def fun(self):
        print("Hi this is fun 2")

obj = A()
obj.fun()

obj = B()
obj.abc()
obj.fun()

"""class PyCharm:
    def execute(self):
        print("Compiling")
        print("Running")

class MyEditor:
    def execute(self):
        print("Spell Check")
        print("Convertion Check")
        print("Comiling")
        print("Running")
class Laptop:
    def code(self,ide):
        ide.execute()

ide = MyEditor()
lap1=Laptop()
lap1.code(ide) """

