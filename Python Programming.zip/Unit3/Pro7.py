import sys


class Bank:
    def __init__(self,name,balance):
        self.name=name
        self.balance=balance
    def deposit(self,amount):
        self.balance += amount
        print("After deposit your balance is:",self.balance)
    def withdraw(self,amount):
        if amount > self.balance:
            print("amount is greater then balance")
        else:
            self.balance -= amount
            print("after withdraw your balance is:",self.balance)

name = input("Enter Name of user:")
bal = int(input("Enter Balance:"))

b1 = Bank(name,bal)
while(True):
    ch=int(input("1.Deposit 2.withdraw 3.exit Enter your choice:"))
    if ch==3:
        sys.exit()
    amount = int(input("Enter amount :"))
    if ch==1:
        b1.deposit(amount)
    elif ch==2:
        b1.withdraw(amount)

