class A:
    def fun(self):
        print("Hii from A")
class B(A):
    def fun(self):
        print("Hello from B")

obj = B()
obj.fun()