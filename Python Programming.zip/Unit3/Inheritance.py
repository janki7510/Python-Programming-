class A:
    def featuare1(self):
        print("Featuare 1 working")

    def featuare2(self):
        print("Featuare 2 working")

class B:
    def featuare3(self):
        print("Featuare 3 working")

    def featuare4(self):
        print("Featuare 4 working")
#A   B
#^   ^
# \ /
#  C
class C(A,B):              #Multiple Inhertiance   
    def featuare5(self):
        print("Featuare 5 working")

"""class B(A):             #single level Inheritance  A<----B
    def featuare3(self):
        print("Featuare 3 working")

    def featuare4(self):
        print("Featuare 4 working")

class C(B):              #Multi Level Inhertiance   A<----B<----C
    def featuare5(self):
        print("Featuare 5 working")"""


a1 = A()
a1.featuare1()
a1.featuare2()
a2 = B()
a2.featuare3()
a3 = C()
a3.featuare2()
