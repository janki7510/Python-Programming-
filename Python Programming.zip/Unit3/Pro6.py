class MyClass:
    n=0
    def __init__(self):
        MyClass.n += 1
    @staticmethod
    def NoObject():
        print("No. of Instance are:",MyClass.n)

obj1=MyClass()
obj2=MyClass()
#MyClass.NoObject()
obj3=MyClass()
MyClass.NoObject()