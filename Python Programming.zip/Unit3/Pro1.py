class Student:
    def __init__(self,name,age,marks):
        self.name=name  #s1.name = JK   (self.name) is an instance object variable
        self.age=age
        self.marks=marks
    def display(self):
        print("Name:",self.name)
        print("Age:",self.age)
        print("Marks:",self.marks)
s1=Student('JK',25,98.89)    #__init__(s1,'JK',25,98.89)
s1.display()
s2=Student('Tae',27,98.77)
s2.display()
