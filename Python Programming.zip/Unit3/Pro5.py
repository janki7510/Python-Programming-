class Student:
    marks=90
    @classmethod
    def fun(cls,name):
        print(f"{name} scored {cls.marks}")

Student.fun("SUGA")
Student.fun("Jhope")