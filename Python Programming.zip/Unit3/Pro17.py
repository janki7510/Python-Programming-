class MyClass:
    def sum(self,a=None,b=None,c=None):
        if a!=None and b!=None and c!=None:
            print("sum of three numbers:",(a+b+c))
        elif a!=None and b!=None:
            print("sum of two numbers:",(a+b))
        else:
            print("Enter 2 or 3 arguments")
o1=MyClass()
o1.sum(10,20,30)
o1.sum(10,20)
o1.sum(10)