class A:
    def __init__(self):
        print("in a init")
    def display(self):
        print("display from A")

class B:
    def __init__(self):
        print("in b init")
    def display(self):
        print("display from B")

class C(A,B):
    def __init__(self):
        super().__init__()   #It will call class A init  and it's call Method Resolution Order(MRO) (It's excute left to right)
        print("in c init")
    def display(self):
        super().display()
        print("display from C")


o1 = C()
o1.display()

"""class B(A):
    def __init__(self):
        super().__init__()  #use of super()
        print("in b init")

o1=B()
"""
