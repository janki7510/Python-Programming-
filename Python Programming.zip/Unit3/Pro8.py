class Emp:
    def __init__(self,id,name,sal):
        self.id=id
        self.name=name
        self.sal=sal
    def display(self):
        print("Id:",self.id,"Name:",self.name,"Salary:",self.sal)

e=Emp(10,"Messi",60000)

class myClass:
    #@staticmethod
    def myMethod(self,e):
        e.sal += 10000
        e.display()

#myClass.myMethod(e)
m1=myClass()
m1.myMethod(e)