#Method Overloading
class Complex:
    def fun(self,x=None,y=None):
        if x==None and y==None:
            print("This is python polymorphism")
        elif x!=None and y==None:
            f=1
            for i in range(1,x):
                f = f*i
            print("Factorial is:",f)
        else:        #both have value
            print("Sum:",x+y)

c1 = Complex()
c1.fun()
c1.fun(5)
c1.fun(7,10)

