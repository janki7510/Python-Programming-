class Dog:
    def bark(self):
        print("Bow Bow")
class Duck:
    def talk(self):
        print("Quack Quack")
class Human:
    def talk(self):
        print("Hello")

def call_me(obj):
    if(hasattr(obj,"bark")):
        obj.bark()
    elif(hasattr(obj,"talk")):
        obj.talk()
    else:
        print("Wrong object is passed")

obj=Dog()
call_me(obj)
obj=Duck()
call_me(obj)
obj=Human()
call_me(obj)
