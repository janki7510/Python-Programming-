list1=['Python',100,30,20,0,40,'Tae']
list2=['python',20,10,43,22,'Tae']

print(list1)
print(list2)

print("common elements")
for i in list1:
    for j in list2:
        if (i==j):
            print(i)

print("uncommon elements")
print("of list1")
for i in list1:
    if i not in list2:
        print(i)

print("uncommon elements")
print("of list2")
for i in list2:
    if i not in list1:
        print(i)

