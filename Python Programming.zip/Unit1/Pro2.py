x1=int(input("Enter x1 value:"))
y1=int(input("Enter y1 value:"))
x2=int(input("Enter x2 value:"))
y2=int(input("Enter y2 value:"))

print("The first complex number is:",complex(x1,y1))
print("The second complex number is:",complex(x2,y2))

z1=complex(x1,y1)
z2=complex(x2,y2)

z3=z1+z2
print("The sum of two complex number is:",z3)