import sys
x=0
while(x!=6):
    print("1. Find Simple Interest")
    print("2. Find area of the Rectangle")
    print("3. Find area of the Triangle")
    print("4. Find area of the Square")
    print("5. Find area of the Circle")
    print("6. Exit")

    x = int(input("Enter your choice:"))

    if (x == 1):
        p = int(input("Enter Principal:"))
        r = int(input("Enter rate:"))
        t = int(input("Enter Time Period:"))
        print("The Simple Interest is:", (p * r * t) / 100)
    elif (x == 2):
        l = int(input("Enter length:"))
        w = int(input("Enter width:"))
        print("Area of Rectangle is:", l * w)
    elif (x == 3):
        b = int(input("Enter base:"))
        h = int(input("Enter height:"))
        print("Area of Triangle is:", 0.5 * b * h)
    elif (x == 4):
        s = int(input("Enter side:"))
        print("Area of Square is:", s * s)
    elif (x == 5):
        r = int(input("Enter radius:"))
        print("Area of Circle is:", 3.14 * r * r)
    else:
        sys.exit()