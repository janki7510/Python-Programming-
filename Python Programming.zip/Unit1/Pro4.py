r=range(1,30,2)
for i in r:
    print(i)