n=[10,20,30,40,100,60,80]
x=bytearray(n)
print("original byte array")
for i in x:
    print(i)

#modification
x[4]=50
x[6]=70

print("Modfied array")
for i in x:
    print(i)