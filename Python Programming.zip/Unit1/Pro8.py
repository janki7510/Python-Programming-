import sys
print("Number of argument is:",len(sys.argv))

even=0
odd=0

n=int(sys.argv[1])
for i in range(1,n):
    print(i)
    if(i%2==0):
        even=even+i
    else:
        odd=odd+i
print("The sum of even number is:",even)
print("The sum of odd number is:",odd)