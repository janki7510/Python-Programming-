num=int(input("Enter a number:"))
assert num>=0, "Only positive numbers accepted."
print('You enterd:',num)