list=[]
n=int(input("Enter a value of n:"))
for i in range(1,n):
    list.append(int(input("Enter the value:")))

search=int(input("Enter search value:"))
for i in list:
    if(search==i):
        print("search value",search)
        break
else:
    print("search value",search ,"not found")