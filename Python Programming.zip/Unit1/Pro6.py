a=int(input("Enter value of a:"))
b=int(input("Enter value of b:"))

print("id of variable a is:",id(a))
print("id of variable b is:",id(b))

if(a is b):
    print("same by using id values")
else:
    print("not same by using id values")

if(a == b):
    print("same by using values")
else:
    print("not same by using values")

if(a is not b):
    print("same by using is not operator")
else:
    print("not same by using is not operator")