
cm=int(input("Enter length in cm:"))
if cm < 0:
    print("Invalid entry")
else:
    print(cm/2.54,"inches")