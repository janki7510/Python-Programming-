#Write a program to create one array from another array
from array import *
arr1 = array('i',[10,20,30,40,50,60,70])
print('Elements of the array are:',arr1)
print('The length of the array is:',len(arr1))
print('The size of the array:',arr1.itemsize)
print('The data type of array elements is:',arr1.typecode)

#create one array from another array

arrNew = array(arr1.typecode,(a for a in arr1))
print('Elements of the new array from the another array:',arrNew)

print("Elements of the new array with *2")
arr2New = array(arr1.typecode,(a*2 for a in arr1))
for i in arr2New:
    print(i)