#list1=[10,20,30,40,10,50,40,60]
list1=[]
n=int(input("Enter how many elements:"))
for i in range(n):
    list1.append(int(input("Enter element:")))

new=[]

for i in list1:
    if i not in new:
        new.append(i)

print("original List:",list1)
print("New list after removing duplicate 7elments:",new)