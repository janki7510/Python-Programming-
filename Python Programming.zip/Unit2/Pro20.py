dict={}
n=int(input("Enter how many elements u want :"))
for i in range(n):
    k=input("Enter key value in form of string type:")
    v=int(input("Enter value in from of int type:"))
    dict.update({k:v})
print("Dictionary:",dict)