from employee import *
basic=float(input("Enter Basic salary of employee:"))
print("Basic salary is:",basic)
gross=basic+da(basic)+hra(basic)
print("GROSS is{:10.2f}".format(gross))
net=gross-it(gross)-pf(basic)
print("NET is:",net)