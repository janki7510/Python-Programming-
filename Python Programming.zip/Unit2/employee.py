#employee.py
def da(basic):
    da=1.2*basic
    print("DA is:",da)
    return da
def hra(basic):
    hra=0.2*basic
    print("HRA is:",hra)
    return hra
def pf(basic):
    pf=0.08*basic
    print("PF is:",pf)
    return pf
def it(gross):
    it=0.1*gross
    print("IT is:",it)
    return it