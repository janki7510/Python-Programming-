tup1=()
list=[]
n=int(input("Enter how many elements u want:"))
for i in range(n):
    list.append(int(input("Enter element:")))
    tup1 = tuple(list)

print("Max:",max(tup1))
print("Min:",min(tup1))
print("Sum:",sum(tup1))
print("Avg:",sum(tup1)/len(tup1))