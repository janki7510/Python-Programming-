def find(n):
    i=2
    while i < n:
        if n % i == 0:
            print("Not Prime")
            break
        i = i + 1
    else:
        print("Prime")


n=int(input("Enter a number:"))
find(n)

"""ans=find(n)
if(ans==1):
    print("Number ",n," is not prime")
else:
    print("Number ",n," is prime")"""


