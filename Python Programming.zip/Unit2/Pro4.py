#write a program to sort the array elements using bubble sort technique
from array import *
arr = array('i',[])

n=int(input("Enter how many element u want:"))

for i in range(n):
    a=int(input("Enter element:"))
    arr.append(a)

"""for i in range(n):
    for j in range(0,n-i-1):
        if arr[j] > arr[j+1]:
            arr[j],arr[j+1] = arr[j+1],arr[j]"""
for i in range(n):
    for j in range(i+1):
        if arr[i] < arr[j]:
            arr[i],arr[j] = arr[j],arr[i]

print("Sorted array:")
for i in arr:
    print(i)