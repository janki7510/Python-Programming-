con=["INDIA","SOUTH KOREA","JAPAN"]
cap=["DELHI","SEOUL","TOKYO"]
z=zip(con,cap)
d=dict(z)
print('COCUNTRY--','CAPITAL')
for k in d:
    print('{}--{}'.format(k,d[k]))
