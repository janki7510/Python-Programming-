from array import *
arr = array('i',[])
n=int(input("Enter how many elements u want:"))
for i in range(n):
    arr.append(int(input("Enter element:")))
search=int(input("Enter element which u want to find :"))
try:
    pos=arr.index(search)
    print("Element found at pos:",pos+1)
except ValueError:
    print("search element ",search," not found")

"""def last_index(arr,search):
    try:
        first_index = arr.index(search)
        next_index=first_index
        while True:
            next_index=arr.index(search,next_index+1)

    except ValueError:
        return next_index


arr=array('i',[10,20,30,40,10,50])
print(arr)
search=int(input("Enter element which u want to find :"))

pos = last_index(arr,search)
print("The last index of " ,search, " in the array is:",pos+1)"""

