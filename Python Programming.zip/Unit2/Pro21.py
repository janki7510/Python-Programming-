dict={}
n=int(input("Enter how many elements u want:"))
for i in range(n):
    k=input("Enter player name:")
    v=int(input("Enter his score value:"))
    dict.update({k:v})
print(dict)
print("players in the match are:")
for players in dict.keys():
    print(players)


name=input("Enter a player name to search his score:")
runs=dict.get(name,-1)
if(runs==-1):
    print("Player not found")
else:
    print("{} made {} runs".format(name,runs))


