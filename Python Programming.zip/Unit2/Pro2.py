#Create a program to reteieve ,display and update only a range of elements from an
#array using indexing and slicing in arrays.
from array import *
arr1 = array('i',[10,20,30,40,50,60,70])
ch=0
while(ch!=8):
    print('1.Display:')
    print('2.update:')
    print('3.Slice 3rd element of the array:')
    print('4.slice element 3,4,5 of the array:')
    print('5. Slice element from the middle of the array to the last element:')
    print('6. print elements with even position:')
    print('7.Update array using slicing')

    ch=int(input("Enter your choice:"))

    if ch==1:
        print(arr1)
    elif ch==2:
        arr1[2]=25
        print("After update the elements are:",arr1)
    elif ch==3:
        print("The third element:",arr1[2:3])
    elif ch==4:
        print("3,4,5 elements are:",arr1[2:5])
    elif ch==5:
        print("element from the middle of the array are:",arr1[int(len(arr1)/2) :])
    elif ch==6:
        for i in range(len(arr1)):
            if((i+1)%2==0):
                print(arr1[i])
    elif ch==7:
        arr1[0:2]= array('i',[5,15])
        print("after updating elements are:",arr1)
    else:
        print("Invalid choice")