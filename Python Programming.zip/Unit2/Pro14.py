list1=list(range(5,10))
print(list1)
list1.append(100)
print("after append 100:",list1)
list1[1]=60
print("after update:",list1)
del list1[1]
print("after delete at pos 1:",list1)