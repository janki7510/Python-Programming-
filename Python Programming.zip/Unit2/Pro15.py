x=[10,20,30,40]
y=[1,2,3,4,5]

x1=x[:] #cloning (it's help u duplicate the content of the original object or data without modifying the original data)
y1=y[:] #y1=y.copy()
y1[0]=100

z=x+y
z1=x1+y1

print("x1=",x1)
print("y1=",y1)
print("combine list z is x+y:",z)
print("combine list z1 x1+y1 is:",z1)
