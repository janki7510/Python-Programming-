list1=[10,20,30,40,[50,60,70]]
print("List:",list1)
print("First element:",list1[0])
print("Second element:",list1[4])
print("All the elements of second element:")
for i in list1[4]:
    print(i)
