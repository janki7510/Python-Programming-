def display(list1):
    for i in list1:
        print(i)
        
list1=[]
n=int(input("Enter how many elements:"))
for i in range(n):
    list1.append(int(input("Enter element:")))
display(list1)

