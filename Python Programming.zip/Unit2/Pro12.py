def simple_fun(x):
    return x*x

def add_three(simple_func):
    def inner(x):
        result=simple_func(x)
        return result+3
    return inner

simple_fun = add_three(simple_fun)
result=simple_fun(5)
print("Result:",result)